b: str
