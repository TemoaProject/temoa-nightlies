
document.addEventListener('DOMContentLoaded', function () {
    // --- Master Datasets (Read from the embedded data in the HTML) ---
    const data = window.GRAPH_DATA;
    const {
        nodes_json_primary: allNodesPrimary,
        edges_json_primary: allEdgesPrimary,
        nodes_json_secondary: allNodesSecondary,
        edges_json_secondary: allEdgesSecondary,
        options_json_str: optionsObject,
        sectors_json_str: allSectors,
        color_legend_json_str: colorLegendData,
        style_legend_json_str: styleLegendData,
        primary_view_name: primaryViewName,
        secondary_view_name: secondaryViewName,
    } = data;

    // --- State ---
    let currentView = 'primary';
    let primaryViewPositions = null;
    let secondaryViewPositions = null;

    // --- DOM Elements ---
    const configWrapper = document.getElementById('config-panel-wrapper');
    const configHeader = document.querySelector('.config-panel-header');
    const advancedControlsToggle = document.getElementById('advanced-controls-toggle');
    const visConfigContainer = document.getElementById('vis-config-container');
    const searchInput = document.getElementById('search-input');
    const resetButton = document.getElementById('reset-view-btn');
    const sectorTogglesContainer = document.getElementById('sector-toggles');
    const viewToggleButton = document.getElementById('view-toggle-btn');
    const graphContainer = document.getElementById('mynetwork');

    // --- Config Panel Toggle ---
    if (optionsObject.configure && optionsObject.configure.enabled) {
        optionsObject.configure.container = visConfigContainer;
        configHeader.addEventListener('click', () => configWrapper.classList.toggle('collapsed'));
        advancedControlsToggle.addEventListener('click', function(e) {
            e.preventDefault();
            const isHidden = visConfigContainer.style.display === 'none';
            visConfigContainer.style.display = isHidden ? 'block' : 'none';
            this.textContent = isHidden ? 'Hide Advanced Physics Controls' : 'Show Advanced Physics Controls';
        });
    }

    // --- Vis.js Network Initialization ---
    const nodes = new vis.DataSet(allNodesPrimary);
    const edges = new vis.DataSet(allEdgesPrimary);
    const network = new vis.Network(graphContainer, { nodes, edges }, optionsObject);

    // --- Core Functions ---
    function applyPositions(positions) {
        if (!positions) return;
        const updates = Object.keys(positions).map(nodeId => ({
            id: nodeId,
            x: positions[nodeId].x,
            y: positions[nodeId].y,
        }));
        if (updates.length > 0) nodes.update(updates);
    }

    function switchView() {
        if (currentView === 'primary') {
            primaryViewPositions = network.getPositions();
        } else {
            secondaryViewPositions = network.getPositions();
        }

        nodes.clear();
        edges.clear();

        if (currentView === 'primary') {
            nodes.add(allNodesSecondary);
            edges.add(allEdgesSecondary);
            currentView = 'secondary';
            viewToggleButton.textContent = `Switch to ${primaryViewName}`;
            applyPositions(secondaryViewPositions);
        } else {
            nodes.add(allNodesPrimary);
            edges.add(allEdgesPrimary);
            currentView = 'primary';
            viewToggleButton.textContent = `Switch to ${secondaryViewName}`;
            applyPositions(primaryViewPositions);
        }
        network.fit();
    }

    function applyAllFilters() {
        const checkedSectors = new Set(Array.from(sectorTogglesContainer.querySelectorAll('input:checked')).map(c => c.value));
        const searchQuery = searchInput.value;
        let regex = null;
        if (searchQuery) {
            try { regex = new RegExp(searchQuery, 'i'); } catch (e) { console.error("Invalid Regex:", e); return; }
        }

        const activeNodesData = (currentView === 'primary') ? allNodesPrimary : allNodesSecondary;
        const activeEdgesData = (currentView === 'primary') ? allEdgesPrimary : allEdgesSecondary;

        const sectorFilteredNodes = activeNodesData.filter(node => {
            let sectorMatch = node.group === null || node.group === undefined || checkedSectors.has(node.group);
            if (currentView === 'primary' && node.color === '#2ca02c') sectorMatch = true;
            return sectorMatch;
        });

        let visibleNodes, visibleEdges;
        if (regex) {
            const seedNodes = sectorFilteredNodes.filter(node => regex.test(node.label || node.id));
            const seedNodeIds = new Set(seedNodes.map(n => n.id));
            const nodesToShowIds = new Set(seedNodeIds);
            activeEdgesData.forEach(edge => {
                if (seedNodeIds.has(edge.from)) nodesToShowIds.add(edge.to);
                if (seedNodeIds.has(edge.to)) nodesToShowIds.add(edge.from);
            });
            visibleNodes = activeNodesData.filter(node => nodesToShowIds.has(node.id));
            visibleEdges = activeEdgesData.filter(edge => nodesToShowIds.has(edge.from) && nodesToShowIds.has(edge.to));
        } else {
            visibleNodes = sectorFilteredNodes;
            const visibleNodeIds = new Set(visibleNodes.map(n => n.id));
            visibleEdges = activeEdgesData.filter(edge => visibleNodeIds.has(edge.from) && visibleNodeIds.has(edge.to));
        }
        nodes.clear();
        edges.clear();
        nodes.add(visibleNodes);
        edges.add(visibleEdges);
    }

    function createTogglesAndLegends() {
        // ... (logic to create toggles and legends)
    }

    // --- Event Listeners & Initial Setup ---
    if (allNodesSecondary && allNodesSecondary.length > 0) {
        viewToggleButton.addEventListener('click', switchView);
    } else {
        document.getElementById('view-toggle-panel').style.display = 'none';
    }
    resetButton.addEventListener('click', () => { /* ... reset logic ... */ });
    searchInput.addEventListener('input', applyAllFilters);
    network.on("doubleClick", params => {
        if (params.nodes.length > 0) { /* ... show neighborhood ... */ }
    });

    viewToggleButton.textContent = `Switch to ${secondaryViewName}`;
    createTogglesAndLegends();
});
